PORT = 8081
# Config directory
# UPLOAD_FOLDER_BACK = '/tmp/uploads/back'
# SAVE_DIR_BACK = '/tmp/results/back'
UPLOAD_FOLDER_BACK = 'Sources/Statics/uploads/back'